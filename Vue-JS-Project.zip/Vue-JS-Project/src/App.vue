<template>
  <div id="app">
    <h1>Product Details</h1>
     <span>Product Name</span>
     <input type = "text" placeholder = "Enter Product Name" v-model = "pname"/>
     <span>Price</span>
     <input type = "number" placeholder = "Enter Price" v-model = "price"/>
     <span>Delivery Status</span>
         <select v-model = "status">
            <option disabled value = "">Please select Status</option>
            <option>Complete</option>
            <option>In Complete</option>
         </select>
         
     <button v-on:click = "showdata" v-bind:style = "styleobj" v-bind:disabled="pname === '' || price === '' || status === '' ">Add</button>
     <br/>
     <br/>
     <table id="firstTable" align="center">
      <thead>
        <tr>
          <th><img src="./assets/delete.png" @click="deleteAllRow()" class='imgHeight'/></th>
          <th>Product</th>
          <th>Price</th>
          <th><span>Delivery Status</span> <img src="./assets/sort.png" @click="sortTableData()" class='sortImgHeight'/></th>
        </tr>
      </thead>
      <tbody v-for="(row,index) in custdet">
        <tr v-if= "index === editedIndex">
          <td><img src="./assets/save.png" @click="saveTableRow(index)" class='imgHeight'/>
          <img src="./assets/edit.png" @click="editTableRow(index)" class='imgHeight'/>
          <img src="./assets/delete.png" @click="deleteTableRow(index)" class='imgHeight'/></td>
          <td><input type='text' v-model="row.pname"></td>
          <td><input type='number' v-model="row.price"></td>
          <td><select v-model = "row.status">
              <option disabled value = "">Please select Status</option>
              <option>Complete</option>
              <option>In Complete</option>
            </select>
          </td>
        </tr>
        <tr v-if= "index !== editedIndex">
          <td><button class='buttonDisable' disabled><img src="./assets/save.png" class='disableImgHeight'/></button>
          <img src="./assets/edit.png" @click="editTableRow(index)" class='imgHeight'/>
          <img src="./assets/delete.png" @click="deleteTableRow(index)" class='imgHeight'/></td>
          <td>{{row.pname}}</td>
          <td>{{row.price}}</td>
          <td>{{row.status}}</td>
        </tr>
      </tbody>
    </table>


  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
       pname:'',
       price:'',
       status : '',
       editedIndex:'',
       custdet:[{pname:'Samsung',price:40000,status:'Complete'},
                {pname:'Vu',price:30000,status:'In Complete'},
                {pname:'Onida',price:60000,status:'Complete'}],
       styleobj: {
          cursor: 'pointer',
          padding: '4px 16px',
          verticalAlign: 'middle',
          margin:'14px'
       }
    }
  },
  methods :{
               showdata : function() {
                  this.custdet.push({
                     pname: this.pname,
                     price: this.price,
                     status : this.status
                  });
                  this.pname = "";
                  this.price = "";
                  this.status = "";
               },
               deleteTableRow: function (idx) { 
                  this.custdet.splice(idx, 1);
                  this.editedIndex='';      
               },
               deleteAllRow: function (){
                  this.editedIndex='';
                  this.custdet=[];
               },
               saveTableRow: function(idx) {
                 this.editedIndex=''; 
                      
               },
               editTableRow:function(idx){
                  this.editedIndex=idx;
               },
               sortTableData: function(){
                  let completeData = this.custdet.filter(e => e.status === 'Complete');
                  let inCompleteData = this.custdet.filter(e => e.status === 'In Complete');

                  function compare(a, b) {
                  const bandA = a.pname.toUpperCase();
                  const bandB = b.pname.toUpperCase();

                  let comparison = 0;
                  if (bandA > bandB) {
                    comparison = 1;
                  } else if (bandA < bandB) {
                    comparison = -1;
                  }
                  return comparison;
                }
                  completeData.sort(compare);
                  inCompleteData.sort(compare);
                  this.custdet=[];
                  Array.prototype.push.apply(completeData,inCompleteData);
                  this.custdet=completeData;
                  console.log(this.custdet,completeData);
               }

            }
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}
tr:nth-child(even) td{
  background-color: #f2f2f2;
}
ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

.buttonDisable{
  border:none;
  background:none;
  cursor:not-allowed;
  pointer-events:all
}

a {
  color: #42b983;
}

table, th, td {
  border: 0.1px solid #ccc;
}
.imgHeight{
  height:40px;
  cursor:pointer;
}
.disableImgHeight{
  height:40px;
}
.sortImgHeight{
 height:20px;
 vertical-align:bottom;
 cursor:pointer; 
}

#firstTable{
  width:50%;
  margin-top:13px;
}

</style>
